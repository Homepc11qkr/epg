# 20190321 11q.kr
cd /mnt/media_rw/sda5/www/html/epg
wget -o xml.log http://192.168.0.33/epg/epg2xml-web.php -O /mnt/media_rw/sda5/www/html/epg/xml.xml
chmod 777 /mnt/media_rw/sda5/www/html/epg/xml.xml
cp /mnt/media_rw/sda5/www/html/epg/xml.xml /mnt/media_rw/sda5/www/html/epg/xmltv.xml

