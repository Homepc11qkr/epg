function writeProgram($programdata) {
    $ChannelId = $programdata['channelId'];
    $startTime = $programdata['startTime'];
    $endTime = $programdata['endTime'];
    $programName = trim(htmlspecialchars($programdata['programName'], ENT_XML1));
    $subprogramName = trim(htmlspecialchars($programdata['subprogramName'], ENT_XML1));
    preg_match('/(.*) \(?(\d+부)\)?/', $programName, $matches);
    if ($matches != NULL) :
        if(isset($matches[1])) $programName = trim($matches[1]) ?: "";
        if(isset($matches[2])) $subprogramName = trim($matches[2]." ".$subprogramName) ?: "";
    endif;//
    if($programName == NULL):
        $programName = $subprogramName;
    endif;
    $actors = htmlspecialchars($programdata['actors'], ENT_XML1);
    $producers = htmlspecialchars($programdata['producers'], ENT_XML1);
    $category = htmlspecialchars($programdata['category'], ENT_XML1);
    $episode = $programdata['episode'];
    if($episode) :
        $episode_ns = (int)$episode - 1;
        $episode_ns = '0' . '.' . $episode_ns . '.' . '0' . '/' . '0';
        $episode_on = $episode;
    endif;
    $rebroadcast = $programdata['rebroadcast'];
    if($episode && $GLOBALS['addepisode'] == 'y') $programName = $programName." (".$episode."회)";
    if($rebroadcast == True && $GLOBALS['addrebroadcast'] == 'y') $programName = $programName." (재)";
    if($programdata['rating'] == 0) :
        $rating = "전체 관람가";
    else :
        $rating = sprintf("%s세 이상 관람가", $programdata['rating']);
    endif;
    if($GLOBALS['addverbose'] == 'y') :
        $desc = $programName;
        if($subprogramName)  $desc = $desc."\n부제 : ".$subprogramName;
        if($rebroadcast == True && $GLOBALS['addrebroadcast']  == 'y') $desc = $desc."\n방송 : 재방송";
        if($episode) $desc = $desc."\n회차 : ".$episode."회";
        if($category) $desc = $desc."\n장르 : ".$category;
        if($actors) $desc = $desc."\n출연 : ".trim($actors);
        if($producers) $desc = $desc."\n제작 : ".trim($producers);
        $desc = $desc."\n등급 : ".$rating;
    else:
        $desc = "";
    endif;
    if($programdata['desc']) $desc = $desc."\n".htmlspecialchars($programdata['desc'], ENT_XML1);
    $desc = preg_replace('/ +/', ' ', $desc);
    $contentTypeDict = array(
        '교양' => 'Arts / Culture (without music)',
        '만화' => 'Cartoons / Puppets',
        '교육' => 'Education / Science / Factual topics',
        '취미' => 'Leisure hobbies',
        '드라마' => 'Movie / Drama',
        '영화' => 'Movie / Drama',
        '음악' => 'Music / Ballet / Dance',
        '뉴스' => 'News / Current affairs',
        '다큐' => 'Documentary',
        '라이프' => 'Documentary',
        '시사/다큐' => 'Documentary',
        '연예' => 'Show / Game show',
        '스포츠' => 'Sports',
        '홈쇼핑' => 'Advertisement / Shopping'
       );
    $contentType = "";
    foreach($contentTypeDict as $key => $value) :
        if(!(strpos($category, $key) === False)) :
            $contentType = $value;
        endif;
    endforeach;

    $splitProgram = ($GLOBALS['prevChannelId'] == $ChannelId and $programName != '' and $GLOBALS['prevProgramName'] == $programName and $GLOBALS['prevEpisode'] == $episode);
    if ($splitProgram) {
        $GLOBALS['buffer']['endTime'] = $endTime;
        $GLOBALS['buffer']['subprogramName'] = '';
        return;
    } else if ($GLOBALS['buffer']) {
        printBuffer();
    }

    $GLOBALS['splitProgram'] = $splitProgram;
    $GLOBALS['prevChannelId'] = $ChannelId;
    $GLOBALS['prevProgramName'] = $programName;
    $GLOBALS['prevEpisode'] = $episode;

    $GLOBALS['buffer'] = [
        'startTime' => $startTime,
        'endTime' => $endTime,
        'ChannelId' => $ChannelId,
        'programName' => $programName,
        'subprogramName' => $subprogramName,
        'desc' => $desc,
        'actors' => $actors,
        'producers' => $producers,
        'category' => $category,
        'contentType' => $contentType,
        'episode' => $episode,
        'episode_ns' => $episode_ns,
        'episode_on' => $episode_on,
        'rebroadcast' => $rebroadcast,
        'rating' => $rating,
    ];
}

function printBuffer() {
    $buffer = $GLOBALS['buffer'];
    if (!$buffer) {
        return;
    }
    
    $fp = $GLOBALS['fp'];
    fprintf($fp, "  <programme start=\"%s +0900\" stop=\"%s +0900\" channel=\"%s\">\n", $buffer['startTime'], $buffer['endTime'], $buffer['ChannelId']);
    fprintf($fp, "    <title lang=\"kr\">%s</title>\n", $buffer['programName']);
    if($buffer['subprogramName']) :
        fprintf($fp, "    <sub-title lang=\"kr\">%s</sub-title>\n", $buffer['subprogramName']);
    endif;
    if($GLOBALS['addverbose']=='y') :
        fprintf($fp, "    <desc lang=\"kr\">%s</desc>\n", $buffer['desc']);
        if($buffer['actors'] || $buffer['producers']):
            fprintf($fp, "    <credits>\n");
            if($buffer['actors']) :
                foreach(explode(',', $buffer['actors']) as $actor):
                    if(trim($actor)) fprintf($fp, "      <actor>%s</actor>\n", trim($actor));
                endforeach;
            endif;
            if($buffer['producers']) :
                foreach(explode(',', $buffer['producers']) as $producer):
                    if(trim($producer)) fprintf($fp, "      <producer>%s</producer>\n", trim($producer));
                endforeach;
            endif;
            fprintf($fp, "    </credits>\n");
        endif;
    endif;
    if($buffer['category']) fprintf($fp, "    <category lang=\"kr\">%s</category>\n", $buffer['category']);
    if($buffer['contentType']) fprintf($fp, "    <category lang=\"en\">%s</category>\n", $buffer['contentType']);
    if($buffer['episode'] && $GLOBALS['addxmltvns']=='y') fprintf($fp, "    <episode-num system=\"xmltv_ns\">%s</episode-num>\n", $buffer['episode_ns']);
    if($buffer['episode'] && $GLOBALS['addxmltvns']!='y') fprintf($fp, "    <episode-num system=\"onscreen\">%s</episode-num>\n", $buffer['episode_on']);
    if($buffer['rebroadcast']) fprintf($fp, "    <previously-shown />\n");
    if($buffer['rating']) :
        fprintf($fp, "    <rating system=\"KMRB\">\n");
        fprintf($fp, "      <value>%s</value>\n", $buffer['rating']);
        fprintf($fp, "    </rating>\n");
    endif;
    fprintf($fp, "  </programme>\n");
}