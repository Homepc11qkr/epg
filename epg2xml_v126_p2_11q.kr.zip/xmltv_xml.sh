#synology
cd /volume1/web/epg
wget -o xml.log http://경로/epg2xml-web.php -O /volume1/web/경로/xml.xml
cp /volume1/web/경로/xml.xml /volume1/web/경로/xmltv.xml

#u5pvr
#cd /mnt/media_rw/sda5/www/html/경로
#wget -o xml.log http://경로/epg2xml-web.php -O /mnt/media_rw/sda5/www/html/경로/xml.xml
#cp /mnt/media_rw/sda5/www/html/경로/xml.xml /mnt/media_rw/sda5/www/html/경로/xmltv.xml
